/*
 * @Author: your name
 * @Date: 2021-01-19 16:39:55
 * @LastEditTime: 2021-01-19 18:32:30
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \mu\src\mu_mobile\index.js
 */

 import './assets/css/index.scss';
//  import $ from './assets/lib/zepto.min.js';
//  import $ from './assets/lib/jquery-3.5.1.min.js'
//  document.querySelector('.button').onclick = function(){
    
//     
//  }

//  document.querySelector('.mu-popup').onclick = function(){
//     document.querySelector('.aaa').classList.remove('z').add('f')

//     // document.querySelector('.mu-popup').style.display = 'none'
//  }
 $(function(){
     $('.button').on('click',function(){
        $('.aaa').removeClass('f').addClass('z').parent().show()
     
     })
     $('.mu-popup').click(function(){
         $(this).find('.aaa').removeClass('z').addClass('f')
         setTimeout(() => {
            $('.mu-popup').hide()
        }, 1000);
     })
 })