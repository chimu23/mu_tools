/*
 * @Author: your name
 * @Date: 2021-01-19 16:39:55
 * @LastEditTime: 2021-01-21 18:21:55
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \mu\src\mu_mobile\index.js
 */

import './assets/css/index.scss';

// 弹窗
class Popup {
    constructor(options) {
        this.muid = Math.random().toString().slice(-6)
        this.animateTime = 300 + 100
        this.originHTML = $(options.originDOM).html()
        this.options = options
        this.options.overlay = this.options.overlay ? true : this.options.overlay == false ? false : true
        console.log(options);
        this.beforeCreate()
    }
    assembleHTML() {
        let HTML = ''
        switch (this.options.direction) {
            default:
                HTML = `<div class="mu-con ${this.options.customClass?this.options.customClass:''}" data-muid="${this.muid}">
        ${this.options.overlay?'<div class="mu--overlay"></div>':''}
        <div class="mu-popup mu-popup--${this.options.direction} mu-animate--popup-${this.options.direction}-a ${this.options.round?'mu-popup-round':''}">
        ${this.options.nav?`<mu-nav>${this.options.nav.close?`<i class="mu-iconfont icon-searchclose ${this.options.nav.close}" data-ops="close"></i>`:''}
        ${this.options.nav.title?`<div class="mu-popup--title">${this.options.nav.title}</div>`:''}</mu-nav>`:''}
        ${this.originHTML}
        </div>
    </div>`
                // break

        }
        return HTML

    }

    // 生命周期
    beforeCreate() {
        console.log('beforeCreate:' + this.muid);

        this.created()
    }
    created() {
        let _this = this
        console.log('created');
        $('body').append(this.assembleHTML())
        // 当动画完全加载完成才绑定点击事件，防止乱点
        setTimeout(() => {
            // click 背影
            $(`[data-muid="${this.muid}"]`).on('click', '.mu--overlay', () => {
                _this.close()
            })
            $(`[data-muid="${this.muid}"]`).on('click', '[data-ops]', function () {
                let $this = $(this)

                switch ($this.data('ops')) {
                    // close 点击了Xicon，关闭弹窗
                    case 'close':
                        _this.close()
                        break
                }
            })
        }, this.animateTime);
    }
    beforeDestroy() {
        // 处理关闭动画
        let handleDOM = $(`[data-muid="${this.muid}"]`).find('.mu-popup')
        handleDOM.removeClass(`mu-animate--popup-${this.options.direction}-a`).addClass(`mu-animate--popup-${this.options.direction}-b`)
        setTimeout(() => {
            handleDOM.removeClass(`mu-animate--popup-${this.options.direction}-b`).parent().remove()
            this.destroyed()
        }, this.animateTime);

    }
    destroyed() {
        // 处理关闭之后的回调
        console.log('destroyed');

    }
    // 生命周期 end

    // close方便外部调用
    close() {
        this.beforeDestroy()
    }
}

// 带icon、文字提示
class Toast {
    constructor(options) {
        this.shutDown = false                               //本次对象关闭状态（只能执行一次关闭流程）
        this.muid = Math.random().toString().slice(-6)
        this.$mu = null                                     //带有muid的DOM
        this.animateTime = 300 + 100                        //动画时长，跟css配合
        this.content = null                                 //文字span DOM(方便直接修改文字)

        this.options = options
        this.options.duration = this.options.duration ? this.options.duration : this.options.duration == 0 ? 0 : 2000 //Toast持续存在时间
        this.options.forbidClick = this.options.forbidClick ? true : this.options.forbidClick == false ? false : true //默认不可点击overlay关闭Toast

        this.beforeCreate()
        console.log(options);

    }
    assembleHTML() {
        let icon = null
        if (this.options.icon) {
            switch (this.options.icon) {
                case 'success':
                    icon = 'icon-dagou'
                    break
                case 'fail':
                    icon = 'icon-gantanhao'
                    break
                case 'loading':
                    icon = 'icon-dengdai'
                    break
            }
        }
        let HTML = `<div class="mu-con ${this.options.customClass?this.options.customClass:''}" data-muid="${this.muid}">
    <div class="mu--overlay ${this.options.overlay?'overlay-nth3':'overlay-nth2'}"></div>
    <div class="mu-toast${icon?'':' mu-toast--text'}">
        ${icon?`<i class="mu-iconfont ${icon}"></i>`:''}
        <span>${this.options.content}</span>
    </div>
</div>`

        return HTML

    }

    // 生命周期
    beforeCreate() {
        this.options.before && this.options.before()
        this.created()
    }
    created() {
        let _this = this
        $('body').append(this.assembleHTML())
        this.$mu = $(`[data-muid="${this.muid}"]`)
        this.content = $('.mu-toast').find('span')
        this.options.after && this.options.after()
        if (this.options.duration) {
            setTimeout(() => {
                _this.close()
            }, this.options.duration);
        }
        if (!this.options.forbidClick) {
            // 允许点击overlay关闭弹窗
            $(`[data-muid="${this.muid}"]`).on('click', '.mu--overlay', () => {
                _this.close()
            })
        }
    }
    beforeDestroy() {
        // 处理关闭动画

        this.$mu.addClass('mu-animate-disappear')

        setTimeout(() => {
            this.$mu.remove()
        }, this.animateTime);

        this.destroyed()

    }
    destroyed() {
        // 处理关闭之后的回调
        console.log('destroyed');
        this.options.close && this.options.close()

    }
    // 生命周期 end

    // close方便外部调用
    close() {
        if (this.shutDown) return
        this.shutDown = true
        this.beforeDestroy()
    }
}


















// class Message {
//     constructor(a) {
//         console.log(a);
//     }
//     k(params) {
//         console.log(params);
//     }
// }

export default {
    Popup,
    Toast
    // Message
}