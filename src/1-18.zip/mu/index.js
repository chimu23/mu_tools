// import $ from 'jquery';

// import {
//   fn
// } from 'jquery';

// require('./index.min.css');
require('./mu.scss');

// imgurl
// gotourl
// platform
// width
// height
// clickEven
// cancelEven

// 弹窗信息组装
// function assembleDialog(options, obj) {
//   console.log(options);
//   let {
//     type = 2,
//       title = '标题',
//       cover = true,
//       content,
//       form,
//       close,
//       width,
//       height,
//       demo,
//       target,
//       top,
//       left,
//       timeout = 2000,
//   } = {
//     ...options,
//   };
//   let HTML = '';
//   switch (type) {
//     case 0:
//       HTML = `
//     <div id="mudialog" data-obj="${obj}">
//     <div class="box-wrap msg" style="top:${top ? top : '40%'};left:${
//         left ? left : '50%'
//       }">
//       <div class="main-box ${form ? form : ''}">
//       <i class="mu-icon msg-label"></i>
//       <div class="text">
//           ${content}
//       </div>
//       ${close ? '<i class="btns close"></i>' : ''}
//       </div>
//     </div>
// </div>
// `;
//       break;
//     case 1:
//       HTML = `
//                 <div id="mudialog" data-obj="${obj}">
//                 <div class="mushadow">
//                 </div>
//                 <div class="box-wrap confirm">
//                     <div class="main-box" style="width:${
//                       width ? width : ''
//                     };height:${height ? height : ''};">
//                         <i class="btns close"></i>
//                         <h3 class="title">
//                             ${title}
//                         </h3>
//                         <div class="text">
//                            ${content}
//                         </div>
//                         <div class="ope-wrap">
//                             <div class="btns confirm">
//                                 确定
//                             </div>
//                             <div class="btns close">
//                                 取消
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>`;
//       break;
//     case 2:
//       HTML = `
//             <div class="mu-popup custom" data-muid="${obj}">
//         ${cover ? '<div class="mu-backgroundCover"></div>' : ''}
//         <div class="mu-content" style="top:${top ? top : '50%'};left:${
//         left ? left : '50%'
//       };">
//         <i class="mu-icon close"></i>
//         </div>
//     </div>`;
//       break;
//     case 3:
//       let targetTop =
//         $(demo).offset().top -
//         $(window || document).scrollTop() -
//         $(demo).outerHeight() - 2;

//       let targetLeft = $(demo).offset().left;
//       HTML = `<div class="miniBlock" data-obj="${obj}" style="top:${targetTop}px;left:${targetLeft}px;position:fixed;">
//             <div class="box-wrap tips">
//                 <div class="main-box">
//                     ${content}
//                 </div>
//             </div>
//         </div>`;
//       break;
//     case 4:
//       HTML = `<div class="miniBlock" data-obj="${obj}" style="${
//         options.demo ? 'position:absolute;' : 'position:fixed;'
//       }${options.top ? 'top:' + options.top + ';' : ''}${
//         options.left ? 'left:' + options.left + ';' : ''
//       }">
//             <div class="box-wrap loading">
//                 <div class="main-boxx">
//                     <p class="mu-bg loading"></p>
//                         <p class="content">${content ? content : ''}</p>
//                 </div>
//             </div>
//         </div>`;
//       break;
//     case 5:
//       HTML = ` <div class="miniBlock" tabindex="0" data-obj="${obj}" style="position:fixed;top:${
//         $(target).offset().top - $(window).scrollTop() + $(target).height() / 2
//       }px;left:${$(target).offset().left + $(target).width() / 2}px">
//     <div class="box-wrap custom">

//     </div>
// </div>
//             `;
//       break;
//   }
//   return HTML;
// }
// 即时消息封装
function assembleMessage(options, OBJ) {
  let HTML_wrap = ''
  let HTML_item = ''
  let existIndex = 0
  let objID = Math.random().toString().slice(-6);

  HTML_wrap = `
  <div class="mu-popup mu-msg ${options.place?options.place:'top'}" data-muid="${OBJ.muid}"></div>`

  if (!$('.mu-popup.mu-msg').length) {
    //  页面上还存在消息，直接插入新消息到消息盒
    $('body').append(HTML_wrap)

  }
  existIndex = $('.mu-popup.mu-msg').find('.mu-content').length

  HTML_item = `
  <div class="mu-animate">
  <div class="mu-content ${options.type||'message'} animate" data-muid="${objID}" style="top:${existIndex*60}px">
    <i class="mu-icon ${options.type||'message'}"></i>
    <span class="mu-msg">${options.content}</span>
    ${options.closeAble?'<i class="mu-icon close"></i>':''}
  </div></div>`

  $('body').find('.mu-popup.mu-msg').append(HTML_item)

  if (options.disappear) {
    // 默认消失
    setTimeout(() => {
      $(`.mu-content[data-muid=${objID}]`).length && closeHandler($(`.mu-content[data-muid=${objID}]`))
    }, options.time);
  }
  // click关闭按钮
  $(`.mu-content[data-muid=${objID}]`).find('.mu-icon.close').on('click', function () {
    closeHandler($(this).parent('.mu-content'))
  })

  function closeHandler(obj) {

    $(obj).css({
      'top': '-80px',
      'opacity': '0'
    })

    setTimeout(() => {
      $(obj).parent().remove()
      $('.mu-popup.mu-msg').find('.mu-animate').each(function (index, item) {
        $(item).find('.mu-content').css('top', index * 60 + 'px')
      })
    }, 200);

    OBJ.finalStatus()
  }
  // 计算每个信息的所在高度
  function calculateTop() {
    // existTop = Math.ceil($('.mu-popup.msg').find('.mu-content').last().outerHeight()) + Math.ceil($('.mu-popup.msg').find('.mu-content').last().position().top) - 10
  }
}
// 自定义弹窗封装
function assembleCustom(options, OBJ) {
  let HTML_wrap = ''
  HTML_wrap = `
  <div class="mu-popup mu-custom" data-muid="${OBJ.muid}" tabindex="0">
${options.cover ? '<div class="mu-BGCover"></div>' : ''}
<div class="mu-center-wrap" style="top:${options.top ? options.top : '50%'};left:${
  options.left ? options.left : '50%'
  };">
<i class="mu-icon close"></i>
<div class="mu-content">

</div>
</div>
</div>`;
  $(options.targetDOM).append(HTML_wrap)

  $(`.mu-popup.mu-custom .mu-content`).append(
    $(options.originDOM).clone().css('display', 'block')
  );
  if (options.noScroll) {
    $('body').css('overflow', 'hidden');
    OBJ.self_finalEven = function () {
      $('body').css('overflow', '');
    };
  }
  options.keyClose && handleKeyColose(OBJ.muid)
  $(`.mu-popup.mu-custom[data-muid=${OBJ.muid}]`).on('click', '.mu-icon.close', function () {

    $(this).parents('.mu-popup.mu-custom').remove()
    OBJ.close()
  })
}

// 确认弹窗封装
function assembleConfirm(options, OBJ) {
  let HTML = ''
  HTML = `<div class="mu-popup mu-confirm" data-muid="${OBJ.muid}" tabindex="0">
  ${options.cover?'<div class="mu-BGCover"></div>':''}
  <div class="mu-center-wrap">
   <div class="mu-content">
      <i class="mu-icon close"></i>
      <div class="mu-title">
          提示
      </div>
      <div class="mu-content-wrap">
          <i class="mu-icon shock"></i>
          <span class="mu-msg">
              ${options.content}
          </span>
      </div>
      <div class="handle-btns">
          <button class="mu-button mu-button-default" data-op="0">取消</button>
          <button class="mu-button mu-button-primary" data-op="1">确认</button>
      </div>
   </div>
  </div>
</div>`
  $('body').append(HTML)
  options.keyClose && handleKeyColose(OBJ.muid)

  $(`.mu-popup.mu-confirm[data-muid=${OBJ.muid}]`).on('click', '.handle-btns button', async function () {
    {
      let op = $(this).data('op')
      if (op) {
        await options.confirm()
        $(this).parents('.mu-popup.mu-confirm').fadeOut()

      } else {
        options.cancel && options.cancel()

      }
      handleClose($(this).parents('.mu-popup.mu-confirm'), OBJ)

    }
  })
  $(`.mu-popup.mu-confirm[data-muid=${OBJ.muid}]`).on('click', '.mu-icon.close', function () {
    handleClose($(this).parents('.mu-popup.mu-confirm'), OBJ)

  })

  function handleClose(DOM) {
    $(DOM).fadeOut()
    setTimeout(() => {
      OBJ.close()
    }, 500);
  }
}

// loading遮罩
function assembleLoadingCover(options, OBJ) {
  let HTML = ''
  HTML = `<div class="mu-popup mu-loading-cover" data-muid="${OBJ.muid}">
  <div class="mu-loading"></div>
  ${options.content?'<div class="mu-loading-text">'+options.content+'</div>':''}
</div>`
  if (!options.allowScroll) {
    $('body').css('overflow', 'hidden');
    OBJ.self_finalEven = function () {
      $('body').css('overflow', '');
    };
  }
  $(options.targetDOM).append(HTML)
}

// 寻址弹窗
function assembleAddressing(options, OBJ) {
  let targetTop =
    $(options.targetDOM).offset().top -
    $(options.targetDOM).outerHeight() - 2;
  let targetLeft = $(options.targetDOM).offset().left;
  console.log(targetTop);
  console.log(targetLeft);
  $(options.originDOM).css({
    top: targetTop + options.offsetTop,
    left: targetLeft + options.offsetLeft
  })
}

// 监听ESC关闭 给弹窗DOM挂载esc事件
function handleKeyColose(muid) {
  $(`.mu-popup[data-muid=${muid}]`).on('keydown', (event) => {
    if (event.keyCode == 27) {
      $(`.mu-popup[data-muid=${muid}]`).find('.mu-icon.close').trigger('click')
    }
  });
}

class Dialog {
  constructor(options) {
    // this.msgTime = 2000; //即时消息弹窗显示时间
    this.sustainTime_msg = 3000 //即时消息弹窗显示时间
    this.muid = null; //本次弹窗对象
    this.options = options || {}; //接收配置参数，closeEven、afterOpenEven
    this.self_finalEven = null; //自身最后需要完成的事件
    this.init();
  }

  /**
   * @method 初始化函数,生成弹窗对象随机数，连接唯一窗口
   */
  init() {
    this.BeginStatus()
    this.muid = Math.random().toString().slice(-6);
  }

  /**
   * @description 消息弹窗open 0
   */
  msg(options) {
    this.open({
      type: 0,
      originContent: {
        disappear: true,
        time: this.sustainTime_msg,
        ...options
      },
    });
    return this.muid
  }

  /**
   * @description 确认弹窗open 1
   */
  confirm(options) {
    this.open({
      type: 1,
      originContent: {
        cover: true,
        ...options
      }
    });
    return this.muid
  }

  /**
   * @description 寻址弹窗type 3
   * @param {Object} options
   */
  addressing(options) {
    this.open({
      type: 3,
      originContent: {
        offsetLeft: 0,
        offsetTop: 0,
        ...options
      }
    })
    return this.muid
  }

  /**
   * @description loading遮罩 open 4
   */
  loading(options) {
    this.open({
      type: 4,
      originContent: {
        allowScroll: true,
        targetDOM: 'body',
        ...options
      }
    });
    return this
  }


  open(options) {
    let {
      type = 2
    } = {
      ...options
    };

    // console.log(options);

    switch (type) {

      case 0:
        assembleMessage(options.originContent, this)
        break;

      case 1:
        assembleConfirm(options.originContent, this)
        break;

      case 2:
        assembleCustom({
          cover: true,
          noScroll: true,
          keyClose: false,
          targetDOM: 'body',
          ...options
        }, this)
        break;

      case 3:
        assembleAddressing({
          ...options.originContent
        }, this)
        break;

      case 4:
        assembleLoadingCover(options.originContent, this)
        break;
    }

    this.options.afterOpenEven && this.options.afterOpenEven();
  }

  close(muid = this.muid) {
    // console.log('本次的muid是' + muid);
    // $(`.mu-popup[data-muid=${this.muid}]`).remove()
    $(`[data-muid=${muid}]`).remove()
    this.self_finalEven && this.self_finalEven()
    this.finalStatus()
  }

  BeginStatus(callback = this.options.beforeEven) {
    callback && callback()

  }
  MiddleStatus(callback = this.options.afterOpenEven) {
    callback && callback()

  }
  finalStatus(callback = this.options.closeEven) {
    callback && callback()
  }
}

export default {
  Dialog,
};